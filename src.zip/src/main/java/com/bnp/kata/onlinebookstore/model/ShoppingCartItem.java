package com.bnp.kata.onlinebookstore.model;

import javax.persistence.*;

import lombok.*;

@Entity
@Table(name = "SHOPPING_CART")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class ShoppingCartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "book_id")
    private Book book;
    private Long userId;
    private int quantity;

}
