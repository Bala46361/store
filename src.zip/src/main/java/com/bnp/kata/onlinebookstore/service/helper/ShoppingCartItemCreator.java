package com.bnp.kata.onlinebookstore.service.helper;

import com.bnp.kata.onlinebookstore.model.Book;
import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;
import org.springframework.stereotype.Component;

@Component
public class ShoppingCartItemCreator {

    public ShoppingCartItem createCartItem(Book book, Long userId, int quantity) {
        return ShoppingCartItem.builder().book(book).userId(userId).quantity(quantity).build();
    }
}
