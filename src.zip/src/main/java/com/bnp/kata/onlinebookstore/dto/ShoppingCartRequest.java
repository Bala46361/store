package com.bnp.kata.onlinebookstore.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShoppingCartRequest {
    private Long cartItemId;
    private Long bookId;
    private Long userId;
    private int quantity;
}
