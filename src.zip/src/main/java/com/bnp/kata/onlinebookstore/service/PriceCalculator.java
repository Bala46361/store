package com.bnp.kata.onlinebookstore.service;

import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;

import java.util.List;

public interface PriceCalculator {
    Double calculateTotalPrice(List<ShoppingCartItem> cartItems);
}