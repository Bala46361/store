package com.bnp.kata.onlinebookstore.service;

import com.bnp.kata.onlinebookstore.dto.LoginRequest;
import com.bnp.kata.onlinebookstore.dto.UserRegisterRequest;
import com.bnp.kata.onlinebookstore.exception.UserAlreadyExistsException;
import com.bnp.kata.onlinebookstore.model.User;
import com.bnp.kata.onlinebookstore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

@Service
public class UserRegistrationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User register(UserRegisterRequest userRegisterRequest) {
        userRepository.findByUserName(userRegisterRequest.getUserName())
                .ifPresent(user -> {
                    throw new UserAlreadyExistsException("User Already exists");
                });

        User user = User.builder()
                .userName(userRegisterRequest.getUserName())
                .password(passwordEncoder.encode(userRegisterRequest.getPassword()))
                .email(Objects.nonNull(userRegisterRequest.getEmail()) ? userRegisterRequest.getEmail() : "")
                .firstName(Objects.nonNull(userRegisterRequest.getFirstName()) ? userRegisterRequest.getFirstName() : "")
                .build();


        return userRepository.save(user);


    }

    public boolean isUserFound(LoginRequest loginRequest) {
        Optional<User> foundUser = userRepository.findByUserName(loginRequest.getUserName());
        if (foundUser.isPresent()) {
            return passwordEncoder.matches(loginRequest.getPassword(), foundUser.get().getPassword());
        }
        return false;
    }
}
