package com.bnp.kata.onlinebookstore.service.impl;

import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;
import com.bnp.kata.onlinebookstore.service.PriceCalculator;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PriceCalculatorImpl implements PriceCalculator {

    @Override
    public Double calculateTotalPrice(List<ShoppingCartItem> cartItems) {
        return cartItems.stream()
                .mapToDouble(cartItem -> cartItem.getQuantity() * cartItem.getBook().getPrice())
                .sum();
    }
}
