package com.bnp.kata.onlinebookstore.controller;

import com.bnp.kata.onlinebookstore.dto.ShoppingCartRequest;
import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;
import com.bnp.kata.onlinebookstore.service.ShoppingCartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class CartControllerTest {

    @Mock
    private ShoppingCartService shoppingCartService;

    @InjectMocks
    private ShoppingCartController shoppingCartController;

    private MockMvc mockMvc;

    private ShoppingCartItem cartItem;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(shoppingCartController).build();

        cartItem = new ShoppingCartItem(1L, null, 1L, 2);
    }

    @Test
    void shouldAddBookToCart_whenValidRequestIsSent() throws Exception {
        ShoppingCartRequest cartRequest = new ShoppingCartRequest(1L, 1L, 1L, 2);
        when(shoppingCartService.addBookToCart(1L, 1L, 2)).thenReturn(cartItem);

        mockMvc.perform(post("/api/cart/add")
                        .contentType("application/json")
                        .content(convertToJson(cartRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.quantity").value(2));

        verify(shoppingCartService, times(1)).addBookToCart(1L, 1L, 2);
    }

    @Test
    void shouldRemoveBookFromCart_whenValidRequestIsSent() throws Exception {
        doNothing().when(shoppingCartService).removeBookFromCart(1L, 1L);

        mockMvc.perform(delete("/api/cart/remove")
                        .param("bookId", "1")
                        .param("userId", "1"))
                .andExpect(status().isNoContent());

        verify(shoppingCartService, times(1)).removeBookFromCart(1L, 1L);
    }

    @Test
    void shouldReturnCartItemsByUserId_whenValidUserIdIsProvided() throws Exception {
        List<ShoppingCartItem> cartItems = Arrays.asList(cartItem);
        when(shoppingCartService.findCartItemsByUserId(1L)).thenReturn(cartItems);

        mockMvc.perform(get("/api/cart/user/{userId}", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].quantity").value(2));

        verify(shoppingCartService, times(1)).findCartItemsByUserId(1L);
    }

    private String convertToJson(ShoppingCartRequest cartRequest) {
        return String.format("{\"bookId\": %d, \"userId\": %d, \"quantity\": %d}",
                cartRequest.getBookId(), cartRequest.getUserId(), cartRequest.getQuantity());
    }
}