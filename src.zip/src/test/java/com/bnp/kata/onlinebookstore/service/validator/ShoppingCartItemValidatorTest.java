package com.bnp.kata.onlinebookstore.service.validator;

import com.bnp.kata.onlinebookstore.exception.UnauthorizedAccessException;
import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ShoppingCartItemValidatorTest {

    private ShoppingCartItemValidator shoppingCartItemValidator;

    @BeforeEach
    public void setUp() {
        shoppingCartItemValidator = new ShoppingCartItemValidator();
    }

    @Test
    public void testValidateUserAuthorization_ShouldNotThrow_WhenUserIsAuthorized() {
        // Arrange
        ShoppingCartItem cartItem = new ShoppingCartItem();
        cartItem.setUserId(1L);

        // Act & Assert
        assertDoesNotThrow(() -> shoppingCartItemValidator.validateUserAuthorization(cartItem, 1L));
    }

    @Test
    public void testValidateUserAuthorization_ShouldThrow_WhenUserIsNotAuthorized() {
        // Arrange
        ShoppingCartItem cartItem = new ShoppingCartItem();
        cartItem.setUserId(1L);

        // Act & Assert
        UnauthorizedAccessException exception = assertThrows(UnauthorizedAccessException.class,
                () -> shoppingCartItemValidator.validateUserAuthorization(cartItem, 2L));
        assertEquals("User not authorized to update this item", exception.getMessage());
    }

    @Test
    public void testValidateUserAuthorization_ShouldThrow_WhenCartItemIsNull() {
        // Act & Assert
        Long userId = 1L;
        assertThrows(NullPointerException.class, () -> shoppingCartItemValidator.validateUserAuthorization(null, userId));
    }

}