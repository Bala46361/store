package com.bnp.kata.onlinebookstore.service;

import com.bnp.kata.onlinebookstore.model.Book;
import com.bnp.kata.onlinebookstore.model.Order;
import com.bnp.kata.onlinebookstore.model.ShoppingCartItem;
import com.bnp.kata.onlinebookstore.repository.OrderRepository;
import com.bnp.kata.onlinebookstore.repository.ShoppingCartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private ShoppingCartRepository cartRepository;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private PriceCalculator priceCalculator;

    @InjectMocks
    private OrderService orderService;

    private ShoppingCartItem cartItem1;
    private ShoppingCartItem cartItem2;

    @BeforeEach
    void setUp() {
        // Initialize test data for shopping cart items
        cartItem1 = new ShoppingCartItem();
        cartItem1.setQuantity(2);
        cartItem1.setBook(new Book(1L, "Book 1", "Williams", 20.0));
        cartItem2 = new ShoppingCartItem();
        cartItem2.setQuantity(1);
        cartItem2.setBook(new Book(2L, "Book 2", "Billiams", 20.0));
    }

    @Test
    void testPlaceOrder_Success() {
        // Arrange
        Long userId = 1L;
        when(cartRepository.findByUserId(userId)).thenReturn(Arrays.asList(cartItem1, cartItem2));
        when(priceCalculator.calculateTotalPrice(anyList())).thenReturn(70.0);
        when(orderRepository.save(any(Order.class)))
                .thenReturn(Order.builder()
                        .id(1L)
                        .userId(1L)
                        .totalPrice(70.0)
                        .orderDate(LocalDateTime.now())
                        .build());
        // Act
        Order order = orderService.placeOrder(userId);

        // Assert
        assertEquals(userId, order.getUserId());
        assertEquals(70.0, order.getTotalPrice());
        verify(orderRepository, times(1)).save(any(Order.class));
        verify(cartRepository, times(1)).deleteAll(anyList());
    }

    @Test
    void testPlaceOrder_CartEmpty() {

        Long userId = 1L;
        when(cartRepository.findByUserId(userId)).thenReturn(Collections.emptyList());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.placeOrder(userId));
        assertEquals("Cart is Empty", exception.getMessage());
    }
}
